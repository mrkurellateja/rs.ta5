# Task-4---Email-Spam-Detection-With-Machine-Learning
Email Spam Detection With Machine Learning

In this task, I used the SMS Spam collection dataset.

Then, I trained the model using a Count Vectorizer and Logistic Regression Algorithms.

There are many analyses that were done, and a few visualizations were also done.

Finally, Using the MultinomialNB Algorithm, made a model and predicted using custom words.
